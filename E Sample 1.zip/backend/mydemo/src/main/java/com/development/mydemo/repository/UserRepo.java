package com.development.mydemo.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.development.mydemo.model.User;

public interface UserRepo extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
}