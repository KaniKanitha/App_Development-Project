package com.development.mydemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MydemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
